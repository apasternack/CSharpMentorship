﻿

namespace Homework3
{
    class EnumsAndStructs
    {

        public struct Grade
        {
            public const double A = 4.0;
            public const double B = 3.0;
            public const double C = 2.0;
            public const double D = 1.0;
            public const double F = 0.0;
        }
    }
}
