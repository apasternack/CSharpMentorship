﻿

namespace Homework3
{
    class Course
    {

        private string _name;

        private double _grade;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public double Grade
        {
            get { return _grade; }
            set { _grade = value; }
        }

    }
}
